<?php
session_start();

function getApiKey() {
    $ch = curl_init('http://mruniquejd.infy.uk/admin/api/keys.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if ($response === false || $httpCode !== 200) {
        $error = curl_error($ch);
        curl_close($ch);
        error_log("API Error: " . $error . " HTTP Code: " . $httpCode);
        return ['success' => false, 'error' => 'API Connection failed'];
    }
    curl_close($ch);
    
    $keys = json_decode($response, true);
    if (!is_array($keys)) {
        return ['success' => false, 'error' => 'Invalid API response format'];
    }
    
    return ['success' => true, 'keys' => $keys];
}

$phone_prefixes = [
    ['prefix' => '91', 'country' => 'India'],
    ['prefix' => '92', 'country' => 'Pakistan'], 
    ['prefix' => '977', 'country' => 'Nepal'],
    ['prefix' => '971', 'country' => 'United Arab Emirates'],
    ['prefix' => '880', 'country' => 'Bangladesh']
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } else {
        $apiResponse = getApiKey();
        if (!$apiResponse['success']) {
            $error = $apiResponse['error'];
        } else {
            $validKey = false;
            foreach ($apiResponse['keys'] as $keyData) {
                if ($keyData['key'] === $password && $keyData['isActive'] === true) {
                    $validKey = true;
                    break;
                }
            }
            
            if ($username === "987650123" && $validKey) {
                $_SESSION['loggedin'] = true;
                header("Location: index.php");
                exit;
            } else {
                $error = "Invalid credentials";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en" translate="no" style="font-size: 37.5px;">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="screen-orientation" content="portrait">
  <meta name="full-screen" content="yes">
  <meta name="HandheldFriendly" content="true">
  <meta name="browsermode" content="application">
  <meta name="x5-fullscreen" content="true">
  <meta name="x5-orientation" content="portrait">
  <meta name="x5-page-mode" content="app">
  <meta name="MobileOptimized" content="320">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,minimal-ui,viewport-fit=cover">
  <meta name="apple-mobile-web-app-title" content="Welcome">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="format-detection" content="telephone=no">
  <meta content="email=no" name="format-detection">
  <title>tc</title>
  <link rel="icon" href="https://res.inbofa999.com/india/upload/1099/bef9ea3c4972f411126f61ee8ba89c1f.png">
  <link rel="stylesheet" type="text/css" href="https://in.piccdn123.com/static/_template_/orange_dm/css/main.css?v=20250416002">
  <link rel="stylesheet" type="text/css" href="https://in.piccdn123.com/static/_template_/orange_dm/css/page-login.css?v=20250416002">
  <link rel="stylesheet" type="text/css" href="https://in.piccdn123.com/static/_template_/orange_dm/css/captcha.css?v=20250416002">

  <style>
    .mobileSelect .content .btnBar .ensure {
        width: auto;
    }
    .chatroom-overlay {
        position: fixed;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, .7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 999;
        touch-action: none;
        max-width: 500px;
        left: 50%;
        transform: translate(-50%, 0);
    }
  </style>
  <link rel="stylesheet" type="text/css" href="https://in.piccdn123.com/static/_template_/orange_dm/css/page-login.css?v=20250416002">
  <link rel="stylesheet" type="text/css" href="https://in.piccdn123.com/static/_template_/orange_dm/css/captcha.css?v=20250416002">
		  <style>
	  .refreshIcon {
	    background-image: url("https://in.piccdn123.com/static/_template_/orange_dm/img/slidecaptcha/icon_light.png");
	  }

	  .sliderIcon{
	    background-image: url("https://in.piccdn123.com/static/_template_/orange_dm/img/slidecaptcha/icon_light.png");
	  }
	  </style>
</head>
<body style="font-size: 12px;">

  <div id="app">
    

    <div class="login__container">

    

      <div class="van-nav-bar van-hairline--bottom">
              
        <a href="javascript:history.go(-1)" class="van-nav-bar__left">
          
            <i class="van-icon van-icon-arrow-left van-nav-bar__arrow">
              
            </i>
          
        </a>
        
        <div class="van-nav-bar__title van-ellipsis">
          <div>
           Login          </div>
        </div>
        <div class="van-nav-bar__right">
          <div class="top-right">

            <div class="cut_language">
              <div class="language">
                <input type="hidden" id="ck_language" value="ck_1099_language">
                <input type="hidden" id="current_language" value="en_us">
                <img src="https://tc9987.com/static/_template_/orange_dm/img/area0.png">
                <span>English</span>
                <i></i>
              </div>
            </div>
          </div>	
        </div>
      </div>

      <div class="login__container-heading">
        <h1 class="login__container-heading__title">
          <font style="vertical-align: inherit;">
            <font style="vertical-align: inherit;">Login</font>
          </font>
        </h1>
        <div class="login__container-heading__subTitle">
          <div>
            <font style="vertical-align: inherit;">
              <font style="vertical-align: inherit;">Please log in using your phone number or email</font>
            </font>
          </div>
          <div>
            <font style="vertical-align: inherit;">
              <font style="vertical-align: inherit;">If you forget your password, please contact customer service.</font>
            </font>
          </div>
        </div>
      </div>

      <div class="login_container-tab">
                  <div class="tab  active " data-tab="phone">
            <div class="phonebg"></div>
            <div class="font30 phonefont30active">
              <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Login in with phone</font>
              </font>
            </div>
          </div>
                  <div class="tab " data-tab="email">
            <div class="emialbg"></div>
            <div class="font30">
              <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Email / Account</font>
              </font>
            </div>
          </div>
              </div>


      <div class="login__container-form">
        <?php if (isset($error)): ?>
        <div class="error-message" style="color: red; text-align: center; margin: 10px 0;">
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" action="" id="loginForm">
            <div class="emailinput__container">
                <div class="emailinput__container-label">
                    <img src="https://in.piccdn123.com/static/_template_/orange_dm/img/sign/emailnumber.png" class="emailinput__container-label__icon">
                    <span>Username</span>
                </div>
                <div class="emailinput__container-input">
                    <input type="text" name="username" id="username" maxlength="250" placeholder="Please enter your username" required>
                </div>
            </div>
            
            <div class="passwordInput__container">
                <div class="passwordInput__container-label">
                    <img class="passwordInput__container-label__icon" src="https://in.piccdn123.com/static/_template_/orange_dm/img/sign/pwd.png">
                    <span>Password</span>
                </div>
                <div class="passwordInput__container-input">
                    <input type="password" id="password" placeholder="Please enter your password" maxlength="32" name="password" required>
                </div>
            </div>
            
            <div class="signIn__container-button">
                <button type="submit" class="submit active">Login</button>
            </div>
        </form>

      <div class="signIn_footer">

           

      </div>
    </div>

  </div>


  <!-- switch language start -->
    <div class="nav-group-language">
    <ul class="">
            <li class="action"   data-language="en_us">
      <div class="left"><img src="/static/_template_/orange_dm/img/area0.png"> <span>English</span></div>
      <i></i>
      </li>
            <li    data-language="hi_in">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>हिंदी</span></div>
      <i></i>
      </li>
            <li    data-language="tamil_in">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>Tamil</span></div>
      <i></i>
      </li>
            <li    data-language="telugu_in">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>Telugu</span></div>
      <i></i>
      </li>
            <li    data-language="bengali">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>Bengali</span></div>
      <i></i>
      </li>
            <li    data-language="marathi_in">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>Marathi</span></div>
      <i></i>
      </li>
            <li    data-language="gujarati_in">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>Gujarati</span></div>
      <i></i>
      </li>
            <li    data-language="kannada_in">
      <div class="left"><img src="/static/_template_/orange_dm/img/area5.png"> <span>Kannada</span></div>
      <i></i>
      </li>
            <li    data-language="punjabi_in">
      <div class="left"><img src="https://tc9987.com/static/_template_/orange_dm/img/area5.png"> <span>Punjabi</span></div>
      <i></i>
      </li>
          </ul>
  </div>
  
	<input type="hidden" value="0" id="isApp">
<input type="hidden" value="https://res.inbofa999.com/india/upload/1099/172db66d4b7172bf374ae6e994346915.png" id="splashImage">
<div class="empty__container template_empty_content" style="display: none">
    <img alt="" src="https://in.piccdn123.com/static/_template_/orange_dm/img/empty.png">
    <p> No data </p>
</div>

<div class="infiniteScroll__loading template_no_more" style="display: none; justify-content: center; box-shadow: none;min-height:auto">
    <div>No more</div>
</div>

<div class="no-data-text" style="display: none">No data</div>

<div class="swal-overlay" id="confirm_dialog" style="display: none">
    <div class="swal-modal">
        <div class="swal-icon swal-icon--warning">
          <span class="swal-icon--warning__body">
              <span class="swal-icon--warning__dot"></span>
          </span>
        </div>
        <div class="swal-text" style=""></div>
        <div class="swal-footer">
            <div class="swal-button-container">
                <button class="swal-button swal-button--confirm">Confirm</button>
            </div>
        </div>
    </div>
</div>

<div class="van-dialog Warning" style="z-index: 9999; display: none;" id="common_confirm_dialog2">

    <div class="van-dialog__header">Warning</div>

    <div class="van-dialog__content">
        <div class="van-dialog__message van-dialog__message--has-title">Are you sure to delete this message?</div>
    </div>

    <div class="van-hairline--top van-dialog__footer">
        <button type="button" class="van-button van-button--large van-dialog__cancel">
            <div class="van-button__content">

                <span class="van-button__text">Cancel</span>

            </div>
        </button>

        <button type="button" class="van-button van-button--large van-dialog__confirm van-hairline--left">
            <div class="van-button__content">

                <span class="van-button__text">Confirm</span>

            </div>
        </button>
    </div>

</div>

<div class="van-overlay" style="z-index: 2001; display: none;"></div>

</body>
</html>
